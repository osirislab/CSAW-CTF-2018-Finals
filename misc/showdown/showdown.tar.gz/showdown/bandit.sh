#!/bin/bash -i
cat <<'EOF'

                            ^
                           | |
                         @#####@
                       (###   ###)-.
                     .(###     ###) \
                    /  (###   ###)   )
                   (=-  .@#####@|_--"
                   /\    \_|l|_/ (\
                  (=-\     |l|    /
                   \  \.___|l|___/
                   /\      |_|   /
                  (=-\._________/\
                   \             /
                     \._________/
                       #  ----  #
                       #   __   #
                       \########/

            "are you feeling lucky, punk?"
EOF
echo

# ~solemn whistling sounds~
sudo su -l cowhand

cat > /mnt/flag <<'EOF'
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo.dWMMMMMMMMK;.xMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM0' '0MMMMMMMWo. oWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMNkxXMMMNl   lNMKkxKMO'  :XMMWWMMMMNXWMMMMMMMMWXKNMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMX; 'oKWO.   .kNl..c0c   .kKd:dWMNx;cXMMMMMN0xcckNMMMMMMM
MMMMMMMMWWWMMMMMMMMMMMMX:   .c,      l.  .'.    ..  :Od'  ;KMWXkl,..;0WMMMMMMMM
MMMMMMMMNkccloxk0XNKdokO;                           ..    'xd:.   .oXMMMMMMMMMM
MMMMMMMMMNx,                         ':::,.      ...             ,OWMMMMMMMMMMM
MMMMMMMMMMMXo.      ,:ccc;           oWMMWk.    .xNdo           .oxkKWMMMMMMMMM
MMMMMMMMMMMMW0c.  0NWMMMMWNk    .;   ,KMMMWO'   '0MkU    .::;.     'OMMMMMMMMMM
MMMMMMMMMMMMMMXd ,KM0lc xNMWo   cX0   oNWMMWO,  '0Mxy  .dXWMWKo.  .dWMMMMMMMMMM
MMMMMMMMMMMWKo,.  oWK:. xNWO,  .xMNl  ,d0MMMM0; '0Mx. .kWXd:oXWk. .,lodxO0KXNWM
MMMMMMMMMMMWNkc.  ,0MNXNWKl.   ,KMMO.  .oWMNWMK;;0Wo' lNX:   :kl.        ..;lkM
MMMWWXKOkdl:,'.    oWMMMMKo.   lWMMNc   ,0MXOXMKOXWl  kWx.          ..,:lxOKNWM
MMoc;'             '0MXkOXWx. .kMNWMk.   oWWxdNMMMNc  0Wl  ....   'd0XWMMMMMMMM
MMMMkxddolcc:;,'.   lNk  )Wk. ,KN  NX:   '0M0;oNMMX:  OWd  :0Xk'   ;kNMMMMMMMMM
MMMMMMMMMMMMMWWKc.  'ONuxKK: .lNX  OWx.   oWNc oNMK,  oW0, .kMx.    'dNMMMMMMMM
MMMMMMMMMMMMMWk,     lNMNk,  .xMNOkXMK,    x0c  :dl.  .kW0odXK; .cdkKNWMMMMMMMM
MMMMMMMMMMMMXd;,:lc. .od     ,0MKxxKWWl.               .dXWW0:  ,0MMMMMMMMMMMMM
MMMMMMMMMMMMNKXWMMk.         .ox    KWd'                 .;,.    ,0WMMMMMMMMMMM
MMMMMMMMMMMMMMMMMNl     ..                                        'OMMMMMMMMMMM
MMMMMMMMMMMMMMMMM0'   .l0d.    ..     .,'.        '.  .;.    :o;.  'OWMMMMMMMMM
MMMMMMMMMMMMMMMMWd. 'dKWWx,;cok0x.   ;0NNx',xd.  'O0c.lXO,   lNWXOdcdXMMMMMMMMM
MMMMMMMMMMMMMMMMXl:xXMMMMNNWMMMMX; .dNMMMWXNMWk. :XMWKXMMXl. ,0MMMMMWWMMMMMMMMM
MMMMMMMMMMMMMMMMWXWMMMMMMMMMMMMMWdc0WMMMMMMMMMWO;oWMMMMMMMNx..xMMMMMMMMMMMMMMMM
EOF
