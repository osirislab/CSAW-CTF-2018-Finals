#!/bin/bash

docker build -t showdown .
mkdir -p showdowns
